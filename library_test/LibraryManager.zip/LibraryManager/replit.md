# LibraryHub - Library Management System

## Overview

LibraryHub is a Django-based library management system designed to manage books, users, and library operations across multiple centers. The application supports role-based access control with different user types including site administrators, librarians, teachers, students, and other staff members. The system is built with a focus on multi-center library management with centralized user administration.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 01, 2025)

### User Management System Implementation
- Created complete user authentication system with email-based login
- Implemented user management with add, edit, delete, and password reset functionality
- Created all necessary views, templates, and URL configurations
- Set up Django server running on port 5000
- Created initial superuser (admin@library.com / admin123) and test centre (Main Centre - MC001)

## System Architecture

### Backend Framework
**Technology**: Django 5.2.6 (Python web framework)

**Rationale**: Django provides a robust, batteries-included framework ideal for building database-driven applications with built-in admin interface, ORM, and authentication system. The choice enables rapid development with strong security defaults.

### Authentication & Authorization

**Custom User Model**: Email-based authentication replacing Django's default username system
- Uses `CustomUser` extending `AbstractUser` with email as `USERNAME_FIELD`
- Custom user manager (`CustomUserManager`) handles user creation and superuser creation
- Password-based authentication with Django's built-in password hashing

**Role-Based Access Control**:
- Multiple boolean flags for roles: `is_librarian`, `is_student`, `is_site_admin`, `is_teacher`, `is_other`
- Django's built-in groups and permissions system for fine-grained access control
- Decorator-based authorization (`@user_passes_test`) for view-level access control
- Hierarchical permission checking (superusers > site admins > regular users)

**Design Decision**: The multi-flag role approach allows users to have multiple roles simultaneously, providing flexibility for staff who may serve in multiple capacities.

### Data Model Architecture

**Centre-Based Multi-Tenancy**:
- `Centre` model with unique `centre_code` for organization identification
- Users linked to centres via foreign key with `SET_NULL` on deletion
- Supports centralized management across multiple library locations

**User Management**:
- Email-based unique identification
- Foreign key relationship to Centre (optional, nullable)
- Integration with Django's built-in Groups and Permissions
- Historical tracking enabled via `simple_history` package

**Core Models**:
1. **CustomUser** - Extended user model with role flags and centre association
2. **Centre** - Library center/location management
3. **Book** - Book inventory with historical tracking
4. **Student** - Student-specific data

### Frontend Architecture

**UI Framework**: TailwindCSS (CDN-based)
- Utility-first CSS framework for rapid UI development
- Custom color scheme:
  - Primary: #143C50 (dark blue)
  - Secondary: #C86450 (coral)
  - Accent: #288CC8 (bright blue)
  - Neutral: #A0A0A0 (gray)
  - Light: #DCDCF0 (light lavender)
  - Danger: #B42828 (red)
- Responsive design with mobile-first approach

**Template Structure**:
- Base template (`base.html`) with header, sidebar, and user menu
- Template inheritance for consistent layout
- Modular URL routing with separate auth and feature-specific URL configurations
- Modal-based forms for user management (add/edit/delete users)

**Design Pattern**: The application uses Django's MTV (Model-Template-View) pattern with template inheritance for code reuse and maintainability.

### URL Routing Structure

**Modular URL Configuration**:
- Main project URLs in `library_management/urls.py`
- App-specific URLs split into modules (`library/urls/__init__.py`, `library/urls/auth.py`)
- Separation of authentication routes from feature routes

**Authentication Routes**:
- `/` - Landing page
- `/auth/login/` - Login page
- `/auth/logout/` - Logout
- `/auth/dashboard/` - User dashboard
- `/auth/profile/` - User profile
- `/auth/change-password/` - Password change
- `/auth/manage-users/` - User management (admin only)
- `/auth/user/add/` - Add new user
- `/auth/user/<id>/update/` - Edit user
- `/auth/user/<id>/delete/` - Delete user
- `/auth/user/<id>/reset-password/` - Reset user password

**Routing Strategy**: Namespaced URL patterns allow for clean separation of concerns and easier maintenance as the application grows.

### Historical Data Tracking

**Technology**: django-simple-history

**Implementation**: `HistoricalRecords` integration for audit trails
- Automatic tracking of model changes
- Preserves historical state for compliance and auditing

**Rationale**: Required for tracking changes in library records, user modifications, and maintaining audit logs for administrative actions.

### View Layer Architecture

**Authentication Flow**:
- Landing page for unauthenticated users
- Email/password login with session-based authentication
- Dashboard redirection after successful login
- Role-based view access with decorator-based guards

**User Management Views**:
- CRUD operations for users (add, update, delete)
- Password reset functionality with hierarchical permissions
- Random password generation for new users
- Transaction-based user creation for data integrity
- Modal-based UI for seamless user experience

**Access Control Pattern**: Views use `@login_required` and `@user_passes_test` decorators to enforce authentication and authorization requirements.

## External Dependencies

### Python Packages
- **Django 5.2.6** - Core web framework
- **django-simple-history 3.10.1** - Model change tracking and audit trails

### Frontend Libraries
- **TailwindCSS** (CDN) - Utility-first CSS framework for styling
- Delivered via `https://cdn.tailwindcss.com`

### Database
- **SQLite** (Django default, development) - File-based database
- Architecture supports migration to PostgreSQL or other production databases
- Django ORM abstracts database operations

### Static Assets
- Inline SVG icons for UI elements
- No external icon library dependencies
- Custom color palette defined in Tailwind configuration

## Current Status

### Implemented Features
✓ Email-based user authentication
✓ Login/logout functionality
✓ User dashboard with role-specific information
✓ User profile management
✓ Password change functionality
✓ User management (add, edit, delete users)
✓ Password reset with random password generation
✓ Role-based access control
✓ Centre assignment for users
✓ Responsive UI with LibraryHub theme
✓ Navigation sidebar with dropdown menus

### Test Credentials
- **Email**: admin@library.com
- **Password**: admin123
- **Role**: Superuser, Site Admin
- **Centre**: Main Centre (MC001)

### Security Considerations
- Django's built-in CSRF protection enabled
- Session-based authentication
- Password hashing using Django's default PBKDF2 algorithm
- `DEBUG = True` currently set (should be disabled for production)
- `ALLOWED_HOSTS = ['*']` set for development (should be restricted for production)
- SECRET_KEY is in settings file (should be moved to environment variables for production)

### Missing/Incomplete Components
- Book management functionality (views referenced but not fully implemented)
- Student management system (model registered but views incomplete)
- Email notification system for password resets
- Production-ready database configuration
- Static file serving configuration for production
- Media file handling for book covers or user avatars
- Rate limiting for login attempts
- Enhanced password validation in change_password view
- Server-side privilege escalation prevention in user management

## Deployment Notes

### Development Server
- Server running on `http://0.0.0.0:5000/`
- Auto-reload enabled for file changes
- Console logs available for debugging

### Before Production Deployment
1. Move `SECRET_KEY` to environment variables
2. Set `DEBUG = False`
3. Restrict `ALLOWED_HOSTS` to specific domains
4. Configure static file serving (collectstatic)
5. Set up production database (PostgreSQL recommended)
6. Enable HTTPS and set `CSRF_COOKIE_SECURE = True`, `SESSION_COOKIE_SECURE = True`
7. Add server-side privilege escalation checks in user management
8. Implement rate limiting for login attempts
9. Set up email backend for password reset notifications
10. Configure logging and monitoring
